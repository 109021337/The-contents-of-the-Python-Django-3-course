from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse
from datetime import datetime

def sayhello(request):
    return HttpResponse("Hello, <a href='https://www.pchome.com.tw/'>PChome</a>")
    
def sayhello1(request, usrname):
    return HttpResponse("Hello" + usrname)
    
def sayhello2(request):
    return HttpResponse("Hello, xikai123")
    
def sayhello3(request, usrname):
    return HttpResponse("Hello" + usrname)

def sayhello4(request, usrname):
    return render(request, "test.html")

def showfoods(request, usrname):
    now = datetime.now()
    food1 = { 'name':'蝦仁滑蛋', 'price':180, 'comment':'好吃', 'is_spicy':False }
    food2 = { 'name':'蒜泥白肉', 'price':160, 'comment':'人氣推薦', 'is_spicy':True }
    food3 = { 'name':'貴妃醉雞', 'price':260, 'comment':'主廚推薦', 'is_spicy':False }
    foods = [food1,food2,food3]
    return render(request, "test1.html", locals())